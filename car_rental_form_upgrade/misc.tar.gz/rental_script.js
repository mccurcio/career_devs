var cars = {
    name: "Matt's Car Rental",
    types: ['Economy', 'Midsize', 'Luxury'],
    economy_number: 10,
    midsize_number: 10,
    luxury_number: 10
    }

window.onload = function() {
    document.getElementById("busName").innerHTML = cars.name;
    }

document.getElementById("econRent").onclick = function() {
    // cars.econBooked++, increment for econcars booked
    cars.economy--; // decrement
    document.getElementById("econAvail").innerHTML = cars.economy;
    // cars.econBooked;
}

document.getElementById("midRent").onclick = function() {
    //cars.midBooked++;
    cars.midsize--; // decrement
    document.getElementById("midAvail").innerHTML = cars.midsize;
    // cars.midBooked;
}

document.getElementById("update").onclick = function() {
  document.getElementById("econCars").innerHTML  = cars.types[0];
  document.getElementById("midCars").innerHTML = cars.types[1];
  document.getElementById("econAvail").innerHTML = cars.economy;
  // cars.econBooked;
  document.getElementById("midAvail").innerHTML = cars.midsize;
  // cars.midBooked;
}
